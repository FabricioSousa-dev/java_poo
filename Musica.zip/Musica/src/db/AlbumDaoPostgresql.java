package db;


import model.Album;
import model.Artista;
import java.sql.*;
import java.util.*;

import db.connetionFactory.ConnectionFactory;

public class AlbumDaoPostgresql implements albumDAO {
    @Override
    public void create(Album album) {
        String sql = "INSERT INTO albuns (alb_id, alb_titulo, alb_ano, alb_art_id) VALUES (?, ?, ?, ?)";
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, album.getId());
            stmt.setString(2, album.getTitulo());
            stmt.setInt(3, album.getAnoLancamento());
            stmt.setInt(4, album.getArtista().getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Album buscarPorId(String id) {
        String sql = "SELECT a.*, ar.art_nome, ar.art_pais FROM albuns a JOIN artistas ar ON a.alb_art_id = ar.art_id WHERE a.alb_id = ?";
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Artista artista = new Artista(
                    rs.getInt("alb_art_id"),
                    rs.getString("art_nome"),
                    rs.getString("art_pais")
                );
                return new Album(
                    rs.getString("alb_id"),
                    rs.getString("alb_titulo"),
                    rs.getInt("alb_ano"),
                    artista
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Album> buscarPorArtista(Artista artista) {
        List<Album> lista = new ArrayList<>();
        String sql = "SELECT * FROM albuns WHERE alb_art_id = ?";
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, artista.getId());
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                lista.add(new Album(
                    rs.getString("alb_id"),
                    rs.getString("alb_titulo"),
                    rs.getInt("alb_ano"),
                    artista
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    @Override
    public void update(Album album) {
        String sql = "UPDATE albuns SET alb_titulo = ?, alb_ano = ?, alb_art_id = ? WHERE alb_id = ?";
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, album.getTitulo());
            stmt.setInt(2, album.getAnoLancamento());
            stmt.setInt(3, album.getArtista().getId());
            stmt.setString(4, album.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void delete(String id) {
        String sql = "DELETE FROM albuns WHERE alb_id = ?";
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
