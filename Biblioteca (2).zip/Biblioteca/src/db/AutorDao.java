package db;

import java.util.List;

import model.Autor;

public interface AutorDao {

	void create(Autor autor);
	Autor read(int id);
	void upadate(Autor autor);
	void delete(int id);
	List<Autor> findybyname(String nome);
	List<Autor> findall();
	
	
}
